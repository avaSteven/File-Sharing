# file_sharing_app/forms.py

from django import forms
from .models import File

class FileUploadForm(forms.ModelForm):
    class Meta:
        model = File
        fields = ['title', 'file']
