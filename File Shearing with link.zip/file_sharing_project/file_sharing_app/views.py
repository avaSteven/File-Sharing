# file_sharing_app/views.py

from django.shortcuts import render, redirect
from .models import File
from .forms import FileUploadForm

def file_upload_view(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('file_list')
    else:
        form = FileUploadForm()
    return render(request, 'file_sharing_app/file_upload.html', {'form': form})

def file_list_view(request):
    files = File.objects.all()
    return render(request, 'file_sharing_app/file_list.html', {'files': files})
