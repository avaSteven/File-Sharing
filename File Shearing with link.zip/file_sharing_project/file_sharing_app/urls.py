# file_sharing_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.file_upload_view, name='file_upload'),
    path('files/', views.file_list_view, name='file_list'),
]
