from django.apps import AppConfig


class FileSharingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'file_sharing_app'
